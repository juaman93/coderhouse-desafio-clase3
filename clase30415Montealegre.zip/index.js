let ahorroTotal = 0;
let salario = parseInt(prompt("Ingresar tu salario:"));
let objetivoAhorro = parseInt(prompt("Ingresar tu objetivo de ahorro:"));
let mes = 1;
let ahorroActual = 0;

while(ahorroTotal <= objetivoAhorro)
{   
    ahorroActual = parseInt(prompt("Cuánto deseas ahorrar el mes " + mes +"?\n\nRecuerda que:\nTu salario es " + salario + "\nTu objetivo de ahorro es " + objetivoAhorro + "\nLlevas ahorrado " + ahorroTotal));
    
    if (ahorroActual > salario)
    {
        alert("No puedes hacer un ahorro mayor a tu salario!");
        continue;
    }
    else
    {
        ahorroTotal += ahorroActual;
        mes++;
    }
    ahorroActual = 0;
}

alert("Ya has terminado tu plan de ahorro!");
